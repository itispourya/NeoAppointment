/*
 * Jalaali JavaScript
 * Copyright (c) 2024
 * Based on jalaali-js by Ebrahim Mohammadi
 * MIT License
 */

(function() {
    'use strict';

    // Helper functions
    function div(a, b) {
        return ~~(a / b);
    }

    function mod(a, b) {
        return a - ~~(a / b) * b;
    }

    // Convert Jalaali year, month, day to Julian day number
    function toJd(jy, jm, jd) {
        var r = jalCal(jy);
        return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
    }

    // Convert Julian day number to Jalaali year, month, day
    function jdToJ(jdn) {
        var gy = jdToG(jdn).gy;
        var jy = gy - 621;
        var r = jalCal(jy);
        var jdn1f = g2d(r.gy, 3, r.march);
        var k = jdn - jdn1f;
        var jm, jd;

        if (k >= 0) {
            if (k <= 185) {
                jm = 1 + div(k, 31);
                jd = mod(k, 31) + 1;
                return {jy: jy, jm: jm, jd: jd};
            }
            k -= 186;
        } else {
            jy -= 1;
            k += 179;
            if (r.leap === 1) k += 1;
        }

        jm = 7 + div(k, 30);
        jd = mod(k, 30) + 1;
        return {jy: jy, jm: jm, jd: jd};
    }

    // Convert Gregorian year, month, day to Julian day number
    function g2d(gy, gm, gd) {
        var d = div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
            div(153 * mod(gm + 9, 12) + 2, 5) + gd - 34840408;
        d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
        return d;
    }

    // Convert Julian day number to Gregorian year, month, day
    function jdToG(jdn) {
        var j, i, gd, gm, gy;
        j = 4 * jdn + 139361631;
        j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
        i = div(mod(j, 1461), 4) * 5 + 308;
        gd = div(mod(i, 153), 5) + 1;
        gm = mod(div(i, 153), 12) + 1;
        gy = div(j, 1461) - 100100 + div(8 - gm, 6);
        return {gy: gy, gm: gm, gd: gd};
    }

    // Calculate Jalaali calendar information
    function jalCal(jy) {
        var breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
        var bl = breaks.length;
        var gy = jy + 621;
        var leapJ = -14;
        var jp = breaks[0];
        var jm, jump, leap, leapG, march, n;

        for (var i = 1; i < bl; i++) {
            jm = breaks[i];
            jump = jm - jp;
            if (jy < jm) break;
            leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
            jp = jm;
        }

        n = jy - jp;
        leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
        if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
        leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
        march = 20 + leapJ - leapG;

        if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
        leap = mod(n + 1, 33);
        if (leap === 0) leap = 32;
        leap = (mod(leap * 8, 33) - 1) / 4;

        return {leap: leap, gy: gy, march: march};
    }

    // Public API
    window.toJalaali = function(gy, gm, gd) {
        return jdToJ(g2d(gy, gm, gd));
    };

    window.toGregorian = function(jy, jm, jd) {
        return jdToG(toJd(jy, jm, jd));
    };

    window.isLeapJalaaliYear = function(jy) {
        return jalCal(jy).leap === 0;
    };

    window.jalaaliMonthLength = function(jy, jm) {
        if (jm <= 6) return 31;
        if (jm <= 11) return 30;
        if (window.isLeapJalaaliYear(jy)) return 30;
        return 29;
    };

    console.log('✅ Jalali library loaded successfully');
})();
