jQuery(document).ready(function($) {
    const shortcodeId = $('.neoappointment-frontend').data('shortcode-id');
    
    let selectedTherapist = null;
    let selectedYear = null;
    let selectedMonth = null;
    let selectedDay = null;
    let todayJalali = null;
    
    const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    const monthNames = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
    
    function toPersianNumerals(num) {
        return String(num).replace(/\d/g, (digit) => persianDigits[parseInt(digit)]);
    }
    
    function toEnglishNumerals(str) {
        return String(str).replace(/[۰-۹]/g, (digit) => persianDigits.indexOf(digit));
    }
    
    function init() {
        // Get today's Jalali date
        const today = new Date();
        todayJalali = window.toJalaali(today.getFullYear(), today.getMonth() + 1, today.getDate());
        
        initYearDropdown();
        
        $('#neo-booking-therapist').on('change', onTherapistChange);
        $('#neo-booking-year').on('change', onYearChange);
        $('#neo-booking-month').on('change', onMonthChange);
        $('#neo-booking-day').on('change', onDayChange);
        $('#neo-booking-form').on('submit', onSubmit);
    }
    
    function initYearDropdown() {
        const $year = $('#neo-booking-year');
        $year.empty();
        $year.append('<option value="">انتخاب کنید</option>');
        
        for (let i = 0; i < 5; i++) { // Show 5 years
            const year = todayJalali.jy + i;
            $year.append(`<option value="${year}">${toPersianNumerals(year)}</option>`);
        }
    }
    
    function onTherapistChange() {
        selectedTherapist = $(this).val();
        resetDropdowns();
        if (selectedTherapist) {
            $('#neo-booking-year').prop('disabled', false);
            
            // Set today's year, month, day
            $('#neo-booking-year').val(todayJalali.jy).trigger('change');
        }
    }
    
    function onYearChange() {
        selectedYear = parseInt($(this).val());
        $('#neo-booking-month').empty();
        $('#neo-booking-month').append('<option value="">انتخاب کنید</option>');
        $('#neo-booking-day').empty().append('<option value="">انتخاب کنید</option>').prop('disabled', true);
        $('#neo-booking-time').empty().append('<option value="">ابتدا تاریخ را انتخاب کنید</option>').prop('disabled', true);
        
        if (selectedYear) {
            for (let i = 1; i <= 12; i++) {
                $('#neo-booking-month').append(`<option value="${i}">${monthNames[i-1]}</option>`);
            }
            $('#neo-booking-month').prop('disabled', false);
            
            // If we're setting today's date, select the month
            if (selectedTherapist && selectedYear === todayJalali.jy) {
                $('#neo-booking-month').val(todayJalali.jm).trigger('change');
            }
        }
    }
    
    function onMonthChange() {
        selectedMonth = parseInt($(this).val());
        $('#neo-booking-day').empty();
        $('#neo-booking-day').append('<option value="">انتخاب کنید</option>');
        $('#neo-booking-time').empty().append('<option value="">ابتدا تاریخ را انتخاب کنید</option>').prop('disabled', true);
        
        if (selectedYear && selectedMonth) {
            const daysInMonth = window.jalaaliMonthLength(selectedYear, selectedMonth);
            loadAvailableDays(selectedYear, selectedMonth, daysInMonth);
        }
    }
    
    function loadAvailableDays(jy, jm, daysInMonth) {
        if (!selectedTherapist) return;
        
        $.ajax({
            url: neoappointment_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'neoappointment_get_available_days',
                therapist_id: selectedTherapist,
                jalali_year: jy,
                jalali_month: jm,
                days_in_month: daysInMonth,
                nonce: neoappointment_ajax.nonce
            },
            success: function(response) {
                $('#neo-booking-day').empty();
                $('#neo-booking-day').append('<option value="">انتخاب کنید</option>');
                
                if (response.success && response.data.available_days) {
                    response.data.available_days.forEach(function(day) {
                        $('#neo-booking-day').append(`<option value="${day}">${toPersianNumerals(day)}</option>`);
                    });
                }
                
                $('#neo-booking-day').prop('disabled', false);
                
                // If we're setting today's date, select the day if available
                if (selectedTherapist && selectedYear === todayJalali.jy && selectedMonth === todayJalali.jm) {
                    const todayDayOption = $(`#neo-booking-day option[value="${todayJalali.jd}"]`);
                    if (todayDayOption.length) {
                        $('#neo-booking-day').val(todayJalali.jd).trigger('change');
                    }
                }
            },
            error: function() {
                // Fallback: show all days
                $('#neo-booking-day').empty();
                $('#neo-booking-day').append('<option value="">انتخاب کنید</option>');
                for (let i = 1; i <= daysInMonth; i++) {
                    $('#neo-booking-day').append(`<option value="${i}">${toPersianNumerals(i)}</option>`);
                }
                $('#neo-booking-day').prop('disabled', false);
                
                // If we're setting today's date, select the day
                if (selectedTherapist && selectedYear === todayJalali.jy && selectedMonth === todayJalali.jm) {
                    $('#neo-booking-day').val(todayJalali.jd).trigger('change');
                }
            }
        });
    }
    
    function onDayChange() {
        selectedDay = parseInt($(this).val());
        $('#neo-booking-time').empty().append('<option value="">در حال بارگذاری...</option>').prop('disabled', false);
        
        if (selectedYear && selectedMonth && selectedDay && selectedTherapist) {
            // Convert Jalali to Gregorian
            const gregorian = window.toGregorian(selectedYear, selectedMonth, selectedDay);
            const dateStr = `${gregorian.gy}-${String(gregorian.gm).padStart(2, '0')}-${String(gregorian.gd).padStart(2, '0')}`;
            $('#neo-booking-date').val(dateStr);
            
            loadAvailableTimes(selectedTherapist, dateStr);
        }
    }
    
    function loadAvailableTimes(therapistId, dateStr) {
        $.ajax({
            url: neoappointment_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'neoappointment_get_available_times',
                therapist_id: therapistId,
                date: dateStr,
                nonce: neoappointment_ajax.nonce
            },
            success: function(response) {
                $('#neo-booking-time').empty();
                if (response.success && response.data.length > 0) {
                    $('#neo-booking-time').append('<option value="">انتخاب کنید</option>');
                    response.data.forEach(function(time) {
                        $('#neo-booking-time').append(`<option value="${time}">${toPersianNumerals(time)}</option>`);
                    });
                } else {
                    $('#neo-booking-time').append('<option value="">زمانی برای این تاریخ در دسترس نیست</option>');
                }
            },
            error: function() {
                $('#neo-booking-time').empty();
                $('#neo-booking-time').append('<option value="">خطا در بارگذاری زمان‌ها</option>');
            }
        });
    }
    
    function resetDropdowns() {
        $('#neo-booking-year').val('').prop('disabled', true);
        $('#neo-booking-month').empty().append('<option value="">انتخاب کنید</option>').prop('disabled', true);
        $('#neo-booking-day').empty().append('<option value="">انتخاب کنید</option>').prop('disabled', true);
        $('#neo-booking-time').empty().append('<option value="">ابتدا اسکین تراپیست و تاریخ را انتخاب کنید</option>').prop('disabled', true);
        $('#neo-booking-date').val('');
        selectedYear = null;
        selectedMonth = null;
        selectedDay = null;
    }
    
    function onSubmit(e) {
        e.preventDefault();
        
        const messageDiv = $('#neo-booking-message');
        messageDiv.hide();
        
        $.ajax({
            url: neoappointment_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'neoappointment_book_appointment',
                therapist_id: $('#neo-booking-therapist').val(),
                first_name: $('#neo-booking-firstname').val(),
                last_name: $('#neo-booking-lastname').val(),
                phone: $('#neo-booking-phone').val(),
                service_type: $('#neo-booking-service').val(),
                appointment_date: $('#neo-booking-date').val(),
                appointment_time: $('#neo-booking-time').val(),
                nonce: neoappointment_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    messageDiv.removeClass('error').addClass('success');
                    messageDiv.text(response.data.message);
                    messageDiv.show();
                    $('#neo-booking-form')[0].reset();
                    resetDropdowns();
                    initYearDropdown();
                } else {
                    messageDiv.removeClass('success').addClass('error');
                    messageDiv.text(response.data.message || 'خطایی رخ داده است');
                    messageDiv.show();
                }
            },
            error: function() {
                messageDiv.removeClass('success').addClass('error');
                messageDiv.text('خطایی رخ داده است');
                messageDiv.show();
            }
        });
    }
    
    init();
});
