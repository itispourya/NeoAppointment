jQuery(document).ready(function($) {
    console.log('✅ NeoAppointment admin.js loaded successfully');
    
    // Color picker sync
    const colorKeys = [
        'color_bg_primary',
        'color_bg_secondary',
        'color_bg_tertiary',
        'color_text_primary',
        'color_text_secondary',
        'color_btn_primary_1',
        'color_btn_primary_2',
        'color_btn_secondary_1',
        'color_btn_secondary_2',
        'color_success',
        'color_error',
        'color_text',
        'color_input_bg',
        'color_select_bg'
    ];
    
    colorKeys.forEach(function(key) {
        const picker = $('#' + key + '_picker');
        const text = $('#' + key + '_text');
        
        if (picker.length && text.length) {
            // Picker change -> update text
            picker.on('input change', function() {
                text.val($(this).val());
            });
            
            // Text change -> update picker (if possible)
            text.on('input', function() {
                let value = $(this).val().trim();
                
                // Try to parse as hex
                if (value && !value.startsWith('#')) {
                    value = '#' + value;
                }
                
                // Only update picker if it's a valid 3/6-digit hex
                if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(value)) {
                    picker.val(value);
                }
                // For RGB/RGBA/8-digit hex, we can't update picker, but that's okay
            });
        }
    });
    
    let currentMonth = new Date();
    let currentJalaliYear = 0;
    let currentJalaliMonth = 0;
    
    function toPersianNumerals(num) {
        const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(num).replace(/\d/g, (digit) => persianDigits[parseInt(digit)]);
    }
    
    function initCalendar() {
        console.log('🗓️ Initializing NeoAppointment calendar...');
        
        // Check if jalaali functions are available
        if (typeof window.toJalaali === 'undefined') {
            console.error('❌ jalaali.js functions not found!');
            $('#neo-calendar').html('<div style="color: #ff0000; padding: 20px; text-align: center;">خطا: فایل jalaali.js بارگذاری نشده است</div>');
            return;
        }
        
        console.log('✅ toJalaali is available');
        
        try {
            renderCalendar(currentMonth);
        } catch (error) {
            console.error('❌ Error rendering calendar:', error);
            $('#neo-calendar').html('<div style="color: #ff0000; padding: 20px; text-align: center;">خطا در نمایش تقویم: ' + error.message + '</div>');
        }
    }
    
    function renderCalendar(date) {
        console.log('📅 Rendering calendar for date:', date);
        
        const calendar = $('#neo-calendar');
        
        if (!calendar.length) {
            console.error('❌ Calendar container #neo-calendar not found!');
            return;
        }
        
        calendar.empty();
        
        // First, convert the given date to Jalali to get the correct month/year
        let todayJalali;
        try {
            todayJalali = window.toJalaali(date.getFullYear(), date.getMonth() + 1, date.getDate());
            console.log('📆 Today Jalali:', todayJalali);
        } catch (error) {
            console.error('❌ Error converting to Jalali:', error);
            calendar.html('<div style="color: #ff0000; padding: 20px;">خطا در تبدیل تاریخ: ' + error.message + '</div>');
            return;
        }
        
        // Set current Jalali month/year from the given date
        currentJalaliYear = todayJalali.jy;
        currentJalaliMonth = todayJalali.jm;
        
        console.log('📅 Current Jalali:', currentJalaliYear, '/', currentJalaliMonth);
        
        // Find first day of the current Jalali month in Gregorian
        let firstDayOfJalaliMonthGregorian = window.toGregorian(currentJalaliYear, currentJalaliMonth, 1);
        let firstDayDate = new Date(firstDayOfJalaliMonthGregorian.gy, firstDayOfJalaliMonthGregorian.gm - 1, firstDayOfJalaliMonthGregorian.gd);
        
        let lastDayOfJalaliMonth = window.jalaaliMonthLength(currentJalaliYear, currentJalaliMonth);
        
        const monthNames = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
        
        // Update month title
        const $monthTitle = $('#neo-current-month');
        if ($monthTitle.length) {
            $monthTitle.text(monthNames[currentJalaliMonth - 1] + ' ' + toPersianNumerals(currentJalaliYear));
        }
        
        // Add day headers
        const dayHeaders = ['شنبه', 'یک‌شنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه'];
        dayHeaders.forEach(day => {
            calendar.append('<div class="neo-calendar-day-header" style="background: rgba(0,210,255,0.2); padding: 10px; text-align: center; border-radius: 5px;">' + day + '</div>');
        });
        
        // Days before current month (previous month)
        let firstDayOfWeek = (firstDayDate.getDay() + 1) % 7; // Adjust for Saturday start
        if (firstDayOfWeek < 0) firstDayOfWeek += 7;
        
        // Get previous month
        let prevJalaliMonth = currentJalaliMonth === 1 ? 12 : currentJalaliMonth - 1;
        let prevJalaliYear = prevJalaliMonth === 12 ? currentJalaliYear - 1 : currentJalaliYear;
        let prevMonthDays = window.jalaaliMonthLength(prevJalaliYear, prevJalaliMonth);
        
        for (let i = firstDayOfWeek - 1; i >= 0; i--) {
            let day = prevMonthDays - i;
            let dayGregorian = window.toGregorian(prevJalaliYear, prevJalaliMonth, day);
            let dateStr = dayGregorian.gy + '-' + String(dayGregorian.gm).padStart(2, '0') + '-' + String(dayGregorian.gd).padStart(2, '0');
            
            calendar.append('<div class="neo-calendar-day other-month" data-date="' + dateStr + '" style="opacity: 0.3; padding: 10px; text-align: center; border-radius: 5px;">' + toPersianNumerals(day) + '</div>');
        }
        
        // Current month
        let today = new Date();
        today.setHours(0, 0, 0, 0);
        
        for (let i = 1; i <= lastDayOfJalaliMonth; i++) {
            let dayGregorian = window.toGregorian(currentJalaliYear, currentJalaliMonth, i);
            let dateStr = dayGregorian.gy + '-' + String(dayGregorian.gm).padStart(2, '0') + '-' + String(dayGregorian.gd).padStart(2, '0');
            
            let classes = 'neo-calendar-day';
            let styles = 'padding: 10px; text-align: center; border-radius: 5px; cursor: pointer; transition: all 0.3s;';
            let currentDateObj = new Date(dayGregorian.gy, dayGregorian.gm - 1, dayGregorian.gd);
            currentDateObj.setHours(0, 0, 0, 0);
            
            if (currentDateObj.getTime() === today.getTime()) {
                classes += ' today';
                styles += ' border: 2px solid #00d2ff; color: #00d2ff;';
            } else {
                styles += ' background: rgba(255,255,255,0.1);';
            }
            
            const dayElement = $('<div class="' + classes + '" data-date="' + dateStr + '" style="' + styles + '">' + toPersianNumerals(i) + '</div>');
            calendar.append(dayElement);
            
            checkAppointments(dateStr, dayElement);
        }
        
        // Days after current month (next month)
        let totalCells = firstDayOfWeek + lastDayOfJalaliMonth;
        let remainingCells = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
        
        let nextJalaliMonth = currentJalaliMonth === 12 ? 1 : currentJalaliMonth + 1;
        let nextJalaliYear = nextJalaliMonth === 1 ? currentJalaliYear + 1 : currentJalaliYear;
        
        for (let i = 1; i <= remainingCells; i++) {
            let dayGregorian = window.toGregorian(nextJalaliYear, nextJalaliMonth, i);
            let dateStr = dayGregorian.gy + '-' + String(dayGregorian.gm).padStart(2, '0') + '-' + String(dayGregorian.gd).padStart(2, '0');
            
            calendar.append('<div class="neo-calendar-day other-month" data-date="' + dateStr + '" style="opacity: 0.3; padding: 10px; text-align: center; border-radius: 5px;">' + toPersianNumerals(i) + '</div>');
        }
        
        console.log('✅ Calendar rendered successfully');
    }
    
    function checkAppointments(date, element) {
        if (typeof neoappointment_ajax === 'undefined') {
            console.warn('⚠️ neoappointment_ajax not available');
            return;
        }
        
        $.ajax({
            url: neoappointment_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'neoappointment_get_appointments',
                date: date,
                nonce: neoappointment_ajax.nonce
            },
            success: function(response) {
                if (response.success && response.data.length > 0) {
                    element.addClass('has-appointments');
                    element.css('position', 'relative');
                    element.append('<span style="position: absolute; bottom: 5px; left: 50%; transform: translateX(-50%); width: 10px; height: 10px; background: #ff416c; border-radius: 50%; box-shadow: 0 0 5px #ff416c;"></span>');
                }
            },
            error: function(error) {
                console.error('❌ Error checking appointments:', error);
            }
        });
    }
    
    $(document).on('click', '#neo-prev-month', function() {
        console.log('👈 Previous month clicked');
        let newJalaliMonth = currentJalaliMonth === 1 ? 12 : currentJalaliMonth - 1;
        let newJalaliYear = newJalaliMonth === 12 ? currentJalaliYear - 1 : currentJalaliYear;
        let firstDayOfNewMonth = window.toGregorian(newJalaliYear, newJalaliMonth, 1);
        currentMonth = new Date(firstDayOfNewMonth.gy, firstDayOfNewMonth.gm - 1, firstDayOfNewMonth.gd);
        renderCalendar(currentMonth);
    });
    
    $(document).on('click', '#neo-next-month', function() {
        console.log('👉 Next month clicked');
        let newJalaliMonth = currentJalaliMonth === 12 ? 1 : currentJalaliMonth + 1;
        let newJalaliYear = newJalaliMonth === 1 ? currentJalaliYear + 1 : currentJalaliYear;
        let firstDayOfNewMonth = window.toGregorian(newJalaliYear, newJalaliMonth, 1);
        currentMonth = new Date(firstDayOfNewMonth.gy, firstDayOfNewMonth.gm - 1, firstDayOfNewMonth.gd);
        renderCalendar(currentMonth);
    });
    
    $(document).on('click', '.neo-calendar-day:not(.other-month)', function() {
        const date = $(this).data('date');
        console.log('📅 Day clicked:', date);
        loadAppointments(date);
    });
    
    function loadAppointments(date) {
        const tbody = $('#neo-appointments-tbody');
        
        if (!tbody.length) {
            console.warn('⚠️ #neo-appointments-tbody not found (this is expected on dashboard page)');
            return;
        }
        
        $.ajax({
            url: neoappointment_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'neoappointment_get_appointments',
                date: date,
                nonce: neoappointment_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    tbody.empty();
                    
                    if (response.data.length === 0) {
                        tbody.append('<tr><td colspan="7" class="neo-empty" style="text-align: center; padding: 20px;">نوبتی برای این تاریخ ثبت نشده است</td></tr>');
                    } else {
                        response.data.forEach(function(appointment) {
                            const statusText = appointment.status === 'completed' ? 'جلسه برگذار شد' : (appointment.status === 'cancelled' ? 'جلسه کنسل شد' : 'در انتظار');
                            const statusClass = appointment.status === 'completed' ? 'background: rgba(76,175,80,0.2); color: #4caf50;' : (appointment.status === 'cancelled' ? 'background: rgba(244,67,54,0.2); color: #f44336;' : 'background: rgba(255,193,7,0.2); color: #ffc107;');
                            
                            tbody.append(`
                                <tr data-appointment='${JSON.stringify(appointment)}'>
                                    <td style="padding: 10px;">${appointment.first_name} ${appointment.last_name}</td>
                                    <td style="padding: 10px;">${appointment.phone}</td>
                                    <td style="padding: 10px;">${appointment.therapist_name}</td>
                                    <td style="padding: 10px;">${appointment.appointment_time}</td>
                                    <td style="padding: 10px;">${appointment.service_type || '-'}</td>
                                    <td style="padding: 10px;"><span style="padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; ${statusClass}">${statusText}</span></td>
                                    <td style="padding: 10px;">
                                        <button class="neo-btn neo-btn-small neo-edit-appointment" style="padding: 5px 10px; font-size: 12px; margin: 2px;">ویرایش</button>
                                        <button class="neo-btn neo-btn-small neo-btn-danger neo-delete-appointment" style="padding: 5px 10px; font-size: 12px; margin: 2px; background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);">حذف</button>
                                    </td>
                                </tr>
                            `);
                        });
                    }
                    
                    $('#neo-selected-date-title').text('نوبت‌های ' + date);
                }
            },
            error: function(error) {
                console.error('❌ Error loading appointments:', error);
            }
        });
    }
    
    $(document).on('click', '#neo-search-btn', function() {
        const date = $('#neo-search-date').val();
        if (date) {
            loadAppointments(date);
            const selectedDate = new Date(date);
            currentMonth = selectedDate;
            renderCalendar(currentMonth);
        }
    });
    
    $(document).on('click', '#neo-add-therapist-btn', function() {
        $('#neo-therapist-modal-title').text('افزودن اسکین تراپیست');
        $('#neo-therapist-form')[0].reset();
        $('#neo-therapist-id').val('');
        $('input[name="working_days[]"]').prop('checked', false);
        $('#neo-therapist-modal').show();
    });
    
    $(document).on('click', '.neo-edit-therapist', function() {
        const therapist = $(this).closest('tr').data('therapist');
        $('#neo-therapist-modal-title').text('ویرایش اسکین تراپیست');
        $('#neo-therapist-id').val(therapist.id);
        $('#neo-therapist-name').val(therapist.name);
        $('#neo-therapist-email1').val(therapist.email1);
        $('#neo-therapist-email2').val(therapist.email2);
        $('#neo-therapist-start').val(therapist.working_hours_start);
        $('#neo-therapist-end').val(therapist.working_hours_end);
        $('#neo-therapist-duration').val(therapist.session_duration);
        
        $('input[name="working_days[]"]').prop('checked', false);
        const workingDays = JSON.parse(therapist.working_days);
        workingDays.forEach(function(day) {
            $('input[name="working_days[]"][value="' + day + '"]').prop('checked', true);
        });
        
        $('#neo-therapist-modal').show();
    });
    
    $(document).on('submit', '#neo-therapist-form', function(e) {
        e.preventDefault();
        
        const workingDays = [];
        $('input[name="working_days[]"]:checked').each(function() {
            workingDays.push($(this).val());
        });
        
        $.ajax({
            url: neoappointment_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'neoappointment_save_therapist',
                id: $('#neo-therapist-id').val(),
                name: $('#neo-therapist-name').val(),
                email1: $('#neo-therapist-email1').val(),
                email2: $('#neo-therapist-email2').val(),
                working_days: workingDays,
                working_hours_start: $('#neo-therapist-start').val(),
                working_hours_end: $('#neo-therapist-end').val(),
                session_duration: $('#neo-therapist-duration').val(),
                nonce: neoappointment_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                }
            },
            error: function(error) {
                console.error('❌ Error saving therapist:', error);
                alert('خطا در ذخیره اسکین تراپیست');
            }
        });
    });
    
    $(document).on('click', '.neo-delete-therapist', function() {
        if (confirm('آیا مطمئن هستید؟')) {
            const therapist = $(this).closest('tr').data('therapist');
            $.ajax({
                url: neoappointment_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'neoappointment_delete_therapist',
                    id: therapist.id,
                    nonce: neoappointment_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    }
                },
                error: function(error) {
                    console.error('❌ Error deleting therapist:', error);
                    alert('خطا در حذف اسکین تراپیست');
                }
            });
        }
    });
    
    $(document).on('click', '.neo-edit-appointment', function() {
        const appointment = $(this).closest('tr').data('appointment');
        $('#neo-appointment-modal-title').text('ویرایش نوبت');
        $('#neo-appointment-id').val(appointment.id);
        $('#neo-appointment-therapist').val(appointment.therapist_id);
        $('#neo-appointment-firstname').val(appointment.first_name);
        $('#neo-appointment-lastname').val(appointment.last_name);
        $('#neo-appointment-phone').val(appointment.phone);
        $('#neo-appointment-service').val(appointment.service_type);
        $('#neo-appointment-date').val(appointment.appointment_date);
        $('#neo-appointment-time').val(appointment.appointment_time);
        $('#neo-appointment-duration').val(appointment.duration);
        $('#neo-appointment-status').val(appointment.status);
        $('#neo-appointment-modal').show();
    });
    
    $(document).on('submit', '#neo-appointment-form', function(e) {
        e.preventDefault();
        
        $.ajax({
            url: neoappointment_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'neoappointment_save_appointment',
                id: $('#neo-appointment-id').val(),
                therapist_id: $('#neo-appointment-therapist').val(),
                first_name: $('#neo-appointment-firstname').val(),
                last_name: $('#neo-appointment-lastname').val(),
                phone: $('#neo-appointment-phone').val(),
                service_type: $('#neo-appointment-service').val(),
                appointment_date: $('#neo-appointment-date').val(),
                appointment_time: $('#neo-appointment-time').val(),
                duration: $('#neo-appointment-duration').val(),
                status: $('#neo-appointment-status').val(),
                nonce: neoappointment_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                }
            },
            error: function(error) {
                console.error('❌ Error saving appointment:', error);
                alert('خطا در ذخیره نوبت');
            }
        });
    });
    
    $(document).on('click', '.neo-delete-appointment', function() {
        if (confirm('آیا مطمئن هستید؟')) {
            const appointment = $(this).closest('tr').data('appointment');
            $.ajax({
                url: neoappointment_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'neoappointment_delete_appointment',
                    id: appointment.id,
                    nonce: neoappointment_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    }
                },
                error: function(error) {
                    console.error('❌ Error deleting appointment:', error);
                    alert('خطا در حذف نوبت');
                }
            });
        }
    });
    
    $(document).on('click', '#neo-add-blocked-day-btn', function() {
        $('#neo-blocked-day-modal-title').text('افزودن روز تعطیل');
        $('#neo-blocked-day-form')[0].reset();
        $('#neo-blocked-day-id').val('');
        $('#neo-blocked-day-modal').show();
    });
    
    $(document).on('click', '.neo-edit-blocked-day', function() {
        const day = $(this).closest('tr').data('blocked-day');
        $('#neo-blocked-day-modal-title').text('ویرایش روز تعطیل');
        $('#neo-blocked-day-id').val(day.id);
        $('#neo-blocked-date').val(day.blocked_date);
        $('#neo-blocked-reason').val(day.reason);
        $('#neo-blocked-day-modal').show();
    });
    
    $(document).on('submit', '#neo-blocked-day-form', function(e) {
        e.preventDefault();
        
        $.ajax({
            url: neoappointment_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'neoappointment_save_blocked_day',
                id: $('#neo-blocked-day-id').val(),
                blocked_date: $('#neo-blocked-date').val(),
                reason: $('#neo-blocked-reason').val(),
                nonce: neoappointment_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                }
            },
            error: function(error) {
                console.error('❌ Error saving blocked day:', error);
                alert('خطا در ذخیره روز تعطیل');
            }
        });
    });
    
    $(document).on('click', '.neo-delete-blocked-day', function() {
        if (confirm('آیا مطمئن هستید؟')) {
            const day = $(this).closest('tr').data('blocked-day');
            $.ajax({
                url: neoappointment_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'neoappointment_delete_blocked_day',
                    id: day.id,
                    nonce: neoappointment_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    }
                },
                error: function(error) {
                    console.error('❌ Error deleting blocked day:', error);
                    alert('خطا در حذف روز تعطیل');
                }
            });
        }
    });
    
    $(document).on('click', '#neo-add-shortcode-btn', function() {
        $('#neo-shortcode-modal-title').text('افزودن شورت‌کد');
        $('#neo-shortcode-form')[0].reset();
        $('#neo-shortcode-id').val('');
        $('input[name="therapist_ids[]"]').prop('checked', false);
        $('#neo-shortcode-modal').show();
    });
    
    $(document).on('click', '.neo-edit-shortcode', function() {
        const shortcode = $(this).closest('tr').data('shortcode');
        $('#neo-shortcode-modal-title').text('ویرایش شورت‌کد');
        $('#neo-shortcode-id').val(shortcode.id);
        $('#neo-shortcode-name').val(shortcode.name);
        
        $('input[name="therapist_ids[]"]').prop('checked', false);
        const therapistIds = JSON.parse(shortcode.therapist_ids);
        if (therapistIds) {
            therapistIds.forEach(function(id) {
                $('input[name="therapist_ids[]"][value="' + id + '"]').prop('checked', true);
            });
        }
        
        $('#neo-shortcode-modal').show();
    });
    
    $(document).on('submit', '#neo-shortcode-form', function(e) {
        e.preventDefault();
        
        const therapistIds = [];
        $('input[name="therapist_ids[]"]:checked').each(function() {
            therapistIds.push($(this).val());
        });
        
        $.ajax({
            url: neoappointment_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'neoappointment_save_shortcode',
                id: $('#neo-shortcode-id').val(),
                name: $('#neo-shortcode-name').val(),
                therapist_ids: therapistIds,
                nonce: neoappointment_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                }
            },
            error: function(error) {
                console.error('❌ Error saving shortcode:', error);
                alert('خطا در ذخیره شورت‌کد');
            }
        });
    });
    
    $(document).on('click', '.neo-delete-shortcode', function() {
        if (confirm('آیا مطمئن هستید؟')) {
            const shortcode = $(this).closest('tr').data('shortcode');
            $.ajax({
                url: neoappointment_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'neoappointment_delete_shortcode',
                    id: shortcode.id,
                    nonce: neoappointment_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    }
                },
                error: function(error) {
                    console.error('❌ Error deleting shortcode:', error);
                    alert('خطا در حذف شورت‌کد');
                }
            });
        }
    });
    
    $(document).on('submit', '#neo-settings-form, #neo-color-settings-form', function(e) {
        e.preventDefault();
        
        $.ajax({
            url: neoappointment_ajax.ajax_url,
            type: 'POST',
            data: $(this).serialize() + '&action=neoappointment_save_settings&nonce=' + neoappointment_ajax.nonce,
            success: function(response) {
                if (response.success) {
                    alert('تنظیمات ذخیره شد');
                }
            },
            error: function(error) {
                console.error('❌ Error saving settings:', error);
                alert('خطا در ذخیره تنظیمات');
            }
        });
    });
    
    $('.neo-close').on('click', function() {
        $(this).closest('.neo-modal').hide();
    });
    
    $(window).on('click', function(e) {
        if ($(e.target).hasClass('neo-modal')) {
            $(e.target).hide();
        }
    });
    
    // Initialize calendar if container exists
    if ($('#neo-calendar').length) {
        console.log('📅 Calendar container found, initializing...');
        initCalendar();
        
        // Load all future appointments by default if we're on appointments page
        if ($('#neo-appointments-tbody').length) {
            $('#neo-selected-date-title').text('نوبت‌های آینده');
            $.ajax({
                url: neoappointment_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'neoappointment_get_appointments',
                    nonce: neoappointment_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        const tbody = $('#neo-appointments-tbody');
                        tbody.empty();
                        
                        if (response.data.length === 0) {
                            tbody.append('<tr><td colspan="7" class="neo-empty" style="text-align: center; padding: 20px;">نوبتی برای آینده ثبت نشده است.</td></tr>');
                        } else {
                            response.data.forEach(function(appointment) {
                                const statusText = appointment.status === 'completed' ? 'جلسه برگذار شد' : (appointment.status === 'cancelled' ? 'جلسه کنسل شد' : 'در انتظار');
                                const statusClass = appointment.status === 'completed' ? 'background: rgba(76,175,80,0.2); color: #4caf50;' : (appointment.status === 'cancelled' ? 'background: rgba(244,67,54,0.2); color: #f44336;' : 'background: rgba(255,193,7,0.2); color: #ffc107;');
                                
                                tbody.append(`
                                    <tr data-appointment='${JSON.stringify(appointment)}'>
                                        <td style="padding: 10px;">${appointment.first_name} ${appointment.last_name}</td>
                                        <td style="padding: 10px;">${appointment.phone}</td>
                                        <td style="padding: 10px;">${appointment.therapist_name}</td>
                                        <td style="padding: 10px;">${appointment.appointment_date} - ${appointment.appointment_time}</td>
                                        <td style="padding: 10px;">${appointment.service_type || '-'}</td>
                                        <td style="padding: 10px;"><span style="padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; ${statusClass}">${statusText}</span></td>
                                        <td style="padding: 10px;">
                                            <button class="neo-btn neo-btn-small neo-edit-appointment" style="padding: 5px 10px; font-size: 12px; margin: 2px;">ویرایش</button>
                                            <button class="neo-btn neo-btn-small neo-btn-danger neo-delete-appointment" style="padding: 5px 10px; font-size: 12px; margin: 2px; background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);">حذف</button>
                                        </td>
                                    </tr>
                                `);
                            });
                        }
                    }
                }
            });
        }
    } else {
        console.warn('⚠️ Calendar container #neo-calendar not found on this page');
    }
});
