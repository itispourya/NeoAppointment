<?php
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$table_shortcodes = $wpdb->prefix . 'neoappointment_shortcodes';
$table_therapists = $wpdb->prefix . 'neoappointment_therapists';
$shortcodes = $wpdb->get_results("SELECT * FROM $table_shortcodes");
$therapists = $wpdb->get_results("SELECT * FROM $table_therapists");
?>

<div class="neoappointment-admin">
    <div class="neo-header">
        <h1>🔗 شورت‌کدها</h1>
        <button id="neo-add-shortcode-btn" class="neo-btn neo-btn-primary">افزودن شورت‌کد جدید</button>
    </div>
    
    <div class="neo-content-section">
        <div class="neo-table-container">
            <table class="neo-table">
                <thead>
                    <tr>
                        <th>نام</th>
                        <th>شورت‌کد</th>
                        <th>اسکین تراپیست‌ها</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($shortcodes)): ?>
                        <tr>
                            <td colspan="4" class="neo-empty">هنوز شورت‌کدی ایجاد نشده است</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($shortcodes as $shortcode): ?>
                            <tr data-shortcode='<?php echo json_encode($shortcode); ?>'>
                                <td><?php echo esc_html($shortcode->name); ?></td>
                                <td><code>[neoappointment id="<?php echo $shortcode->id; ?>"]</code></td>
                                <td>
                                    <?php
                                    $therapist_ids = maybe_unserialize($shortcode->therapist_ids);
                                    if ($therapist_ids && is_array($therapist_ids)) {
                                        $names = array();
                                        foreach ($therapists as $t) {
                                            if (in_array($t->id, $therapist_ids)) {
                                                $names[] = $t->name;
                                            }
                                        }
                                        echo esc_html(implode(', ', $names));
                                    }
                                    ?>
                                </td>
                                <td>
                                    <button class="neo-btn neo-btn-small neo-edit-shortcode">ویرایش</button>
                                    <button class="neo-btn neo-btn-small neo-btn-danger neo-delete-shortcode">حذف</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div id="neo-shortcode-modal" class="neo-modal">
        <div class="neo-modal-content">
            <span class="neo-close">&times;</span>
            <h2 id="neo-shortcode-modal-title">افزودن شورت‌کد</h2>
            <form id="neo-shortcode-form">
                <input type="hidden" id="neo-shortcode-id" name="id">
                
                <div class="neo-form-group">
                    <label>نام شورت‌کد</label>
                    <input type="text" id="neo-shortcode-name" name="name" required>
                </div>
                
                <div class="neo-form-group">
                    <label>اسکین تراپیست‌ها</label>
                    <div class="neo-checkboxes">
                        <?php foreach ($therapists as $therapist): ?>
                            <label><input type="checkbox" name="therapist_ids[]" value="<?php echo $therapist->id; ?>"> <?php echo esc_html($therapist->name); ?></label>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <button type="submit" class="neo-btn neo-btn-primary">ذخیره</button>
            </form>
        </div>
    </div>
</div>
