<?php
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$table_appointments = $wpdb->prefix . 'neoappointment_appointments';
$table_therapists = $wpdb->prefix . 'neoappointment_therapists';
$therapists = $wpdb->get_results("SELECT * FROM $table_therapists");
?>

<div class="neoappointment-admin">
    <div class="neo-header">
        <h1>📋 نوبت‌ها</h1>
        <div class="neo-search-box">
            <input type="date" id="neo-search-date" placeholder="جستجو بر اساس تاریخ">
            <button id="neo-search-btn" class="neo-btn">جستجو</button>
        </div>
    </div>
    
    <div id="neo-calendar-debug" style="background: rgba(0,255,0,0.2); padding: 10px; margin-bottom: 10px; border-radius: 5px;">
        <strong>تست تقویم:</strong> اگر این متن را می‌بینید، کانتینر ها در حال بارگذاری هستند.
    </div>
    <div class="neo-calendar-container">
        <div class="neo-calendar-nav">
            <button id="neo-prev-month" class="neo-btn">ماه قبل</button>
            <h3 id="neo-current-month" style="color: #00d2ff; font-size: 20px; border: 1px dashed #00d2ff; padding: 5px;">نام ماه اینجا نمایش داده می‌شود</h3>
            <button id="neo-next-month" class="neo-btn">ماه بعد</button>
        </div>
        <div id="neo-calendar" class="neo-calendar" style="border: 2px dashed #ff0000; min-height: 200px;"></div>
    </div>
    
    <div class="neo-content-section">
        <h2 id="neo-selected-date-title">نوبت‌های امروز</h2>
        <div class="neo-table-container">
            <table class="neo-table">
                <thead>
                    <tr>
                        <th>نام</th>
                        <th>تلفن</th>
                        <th>اسکین تراپیست</th>
                        <th>ساعت</th>
                        <th>نوع خدمت</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody id="neo-appointments-tbody">
                </tbody>
            </table>
        </div>
    </div>
    
    <div id="neo-appointment-modal" class="neo-modal">
        <div class="neo-modal-content">
            <span class="neo-close">&times;</span>
            <h2 id="neo-appointment-modal-title">ویرایش نوبت</h2>
            <form id="neo-appointment-form">
                <input type="hidden" id="neo-appointment-id" name="id">
                
                <div class="neo-form-group">
                    <label>اسکین تراپیست</label>
                    <select id="neo-appointment-therapist" name="therapist_id" required>
                        <?php foreach ($therapists as $therapist): ?>
                            <option value="<?php echo $therapist->id; ?>"><?php echo esc_html($therapist->name); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="neo-form-row">
                    <div class="neo-form-group">
                        <label>نام</label>
                        <input type="text" id="neo-appointment-firstname" name="first_name" required>
                    </div>
                    <div class="neo-form-group">
                        <label>نام خانوادگی</label>
                        <input type="text" id="neo-appointment-lastname" name="last_name" required>
                    </div>
                </div>
                
                <div class="neo-form-group">
                    <label>شماره تماس</label>
                    <input type="text" id="neo-appointment-phone" name="phone" required>
                </div>
                
                <div class="neo-form-group">
                    <label>نوع خدمت</label>
                    <textarea id="neo-appointment-service" name="service_type"></textarea>
                </div>
                
                <div class="neo-form-row">
                    <div class="neo-form-group">
                        <label>تاریخ نوبت</label>
                        <input type="date" id="neo-appointment-date" name="appointment_date" required>
                    </div>
                    <div class="neo-form-group">
                        <label>ساعت نوبت</label>
                        <input type="time" id="neo-appointment-time" name="appointment_time" required>
                    </div>
                </div>
                
                <div class="neo-form-group">
                    <label>مدت جلسه (دقیقه)</label>
                    <input type="number" id="neo-appointment-duration" name="duration" min="15" step="15" value="60" required>
                </div>
                
                <div class="neo-form-group">
                    <label>وضعیت</label>
                    <select id="neo-appointment-status" name="status">
                        <option value="pending">در انتظار</option>
                        <option value="completed">جلسه برگذار شد</option>
                        <option value="cancelled">جلسه کنسل شد</option>
                    </select>
                </div>
                
                <button type="submit" class="neo-btn neo-btn-primary">ذخیره</button>
            </form>
        </div>
    </div>
</div>
