<?php
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$table_settings = $wpdb->prefix . 'neoappointment_settings';
$settings = $wpdb->get_results("SELECT * FROM $table_settings");

$settings_array = array();
foreach ($settings as $setting) {
    $settings_array[$setting->setting_key] = $setting->setting_value;
}
?>

<div class="neoappointment-admin">
    <div class="neo-header">
        <h1>⚙️ تنظیمات</h1>
    </div>
    
    <div class="neo-content-section">
        <h2 style="color: #00d2ff; margin-top: 0; margin-bottom: 25px;">📧 تنظیمات ایمیل و پیام‌ها</h2>
        <form id="neo-settings-form">
            <div class="neo-form-group">
                <label>ایمیل ادمین (دریافت نوبت‌های جدید)</label>
                <input type="email" name="settings[admin_email]" value="<?php echo esc_attr($settings_array['admin_email'] ?? ''); ?>">
            </div>
            
            <div class="neo-form-group">
                <label>پیام موفقیت ثبت نوبت</label>
                <textarea name="settings[success_message]"><?php echo esc_textarea($settings_array['success_message'] ?? ''); ?></textarea>
            </div>
            
            <div class="neo-form-group">
                <label>پیام خطا</label>
                <textarea name="settings[error_message]"><?php echo esc_textarea($settings_array['error_message'] ?? ''); ?></textarea>
            </div>
            
            <div class="neo-form-group">
                <label>پیام تداخل زمان</label>
                <textarea name="settings[time_conflict_message]"><?php echo esc_textarea($settings_array['time_conflict_message'] ?? ''); ?></textarea>
            </div>
        </form>
    </div>
    
    <div class="neo-content-section">
        <h2 style="color: #00d2ff; margin-top: 0; margin-bottom: 25px;">🎨 رنگ‌بندی سمت کاربر</h2>
        <form id="neo-color-settings-form">
            <div class="neo-form-row">
                <div class="neo-form-group">
                    <label>رنگ پس‌زمینه اصلی</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_bg_primary_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_bg_primary'] ?? '#0f0c29')); ?>">
                        <input type="text" id="color_bg_primary_text" name="settings[color_bg_primary]" value="<?php echo esc_attr($settings_array['color_bg_primary'] ?? '#0f0c29'); ?>" style="flex: 1;">
                    </div>
                </div>
                <div class="neo-form-group">
                    <label>رنگ پس‌زمینه ثانویه</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_bg_secondary_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_bg_secondary'] ?? '#302b63')); ?>">
                        <input type="text" id="color_bg_secondary_text" name="settings[color_bg_secondary]" value="<?php echo esc_attr($settings_array['color_bg_secondary'] ?? '#302b63'); ?>" style="flex: 1;">
                    </div>
                </div>
            </div>
            
            <div class="neo-form-row">
                <div class="neo-form-group">
                    <label>رنگ پس‌زمینه سوم</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_bg_tertiary_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_bg_tertiary'] ?? '#24243e')); ?>">
                        <input type="text" id="color_bg_tertiary_text" name="settings[color_bg_tertiary]" value="<?php echo esc_attr($settings_array['color_bg_tertiary'] ?? '#24243e'); ?>" style="flex: 1;">
                    </div>
                </div>
                <div class="neo-form-group">
                    <label>رنگ متن اصلی</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_text_primary_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_text_primary'] ?? '#00d2ff')); ?>">
                        <input type="text" id="color_text_primary_text" name="settings[color_text_primary]" value="<?php echo esc_attr($settings_array['color_text_primary'] ?? '#00d2ff'); ?>" style="flex: 1;">
                    </div>
                </div>
            </div>
            
            <div class="neo-form-row">
                <div class="neo-form-group">
                    <label>رنگ متن ثانویه</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_text_secondary_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_text_secondary'] ?? '#3a7bd5')); ?>">
                        <input type="text" id="color_text_secondary_text" name="settings[color_text_secondary]" value="<?php echo esc_attr($settings_array['color_text_secondary'] ?? '#3a7bd5'); ?>" style="flex: 1;">
                    </div>
                </div>
                <div class="neo-form-group">
                    <label>رنگ دکمه اصلی 1</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_btn_primary_1_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_btn_primary_1'] ?? '#667eea')); ?>">
                        <input type="text" id="color_btn_primary_1_text" name="settings[color_btn_primary_1]" value="<?php echo esc_attr($settings_array['color_btn_primary_1'] ?? '#667eea'); ?>" style="flex: 1;">
                    </div>
                </div>
            </div>
            
            <div class="neo-form-row">
                <div class="neo-form-group">
                    <label>رنگ دکمه اصلی 2</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_btn_primary_2_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_btn_primary_2'] ?? '#764ba2')); ?>">
                        <input type="text" id="color_btn_primary_2_text" name="settings[color_btn_primary_2]" value="<?php echo esc_attr($settings_array['color_btn_primary_2'] ?? '#764ba2'); ?>" style="flex: 1;">
                    </div>
                </div>
                <div class="neo-form-group">
                    <label>رنگ دکمه ثانویه 1</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_btn_secondary_1_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_btn_secondary_1'] ?? '#00d2ff')); ?>">
                        <input type="text" id="color_btn_secondary_1_text" name="settings[color_btn_secondary_1]" value="<?php echo esc_attr($settings_array['color_btn_secondary_1'] ?? '#00d2ff'); ?>" style="flex: 1;">
                    </div>
                </div>
            </div>
            
            <div class="neo-form-row">
                <div class="neo-form-group">
                    <label>رنگ دکمه ثانویه 2</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_btn_secondary_2_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_btn_secondary_2'] ?? '#3a7bd5')); ?>">
                        <input type="text" id="color_btn_secondary_2_text" name="settings[color_btn_secondary_2]" value="<?php echo esc_attr($settings_array['color_btn_secondary_2'] ?? '#3a7bd5'); ?>" style="flex: 1;">
                    </div>
                </div>
                <div class="neo-form-group">
                    <label>رنگ موفقیت</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_success_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_success'] ?? '#4caf50')); ?>">
                        <input type="text" id="color_success_text" name="settings[color_success]" value="<?php echo esc_attr($settings_array['color_success'] ?? '#4caf50'); ?>" style="flex: 1;">
                    </div>
                </div>
            </div>
            
            <div class="neo-form-row">
                <div class="neo-form-group">
                    <label>رنگ خطا</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_error_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_error'] ?? '#f44336')); ?>">
                        <input type="text" id="color_error_text" name="settings[color_error]" value="<?php echo esc_attr($settings_array['color_error'] ?? '#f44336'); ?>" style="flex: 1;">
                    </div>
                </div>
                <div class="neo-form-group">
                    <label>رنگ متن</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_text_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_text'] ?? '#ffffff')); ?>">
                        <input type="text" id="color_text_text" name="settings[color_text]" value="<?php echo esc_attr($settings_array['color_text'] ?? '#ffffff'); ?>" style="flex: 1;">
                    </div>
                </div>
            </div>
            
            <div class="neo-form-row">
                <div class="neo-form-group">
                    <label>رنگ پس‌زمینه ورودی</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_input_bg_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_input_bg'] ?? 'rgba(255,255,255,0.1)')); ?>">
                        <input type="text" id="color_input_bg_text" name="settings[color_input_bg]" value="<?php echo esc_attr($settings_array['color_input_bg'] ?? 'rgba(255,255,255,0.1)'); ?>" style="flex: 1;">
                    </div>
                </div>
                <div class="neo-form-group">
                    <label>رنگ پس‌زمینه کشویی</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="color" id="color_select_bg_picker" style="height: 50px; padding: 0; width: 80px; cursor: pointer;" value="<?php echo esc_attr(NeoAppointment_Admin::extract_hex_for_picker($settings_array['color_select_bg'] ?? 'rgba(255,255,255,0.1)')); ?>">
                        <input type="text" id="color_select_bg_text" name="settings[color_select_bg]" value="<?php echo esc_attr($settings_array['color_select_bg'] ?? 'rgba(255,255,255,0.1)'); ?>" style="flex: 1;">
                    </div>
                </div>
            </div>
            
            <button type="submit" class="neo-btn neo-btn-primary">ذخیره رنگ‌ها</button>
        </form>
    </div>
</div>
