<?php
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$table_therapists = $wpdb->prefix . 'neoappointment_therapists';
$therapists = $wpdb->get_results("SELECT * FROM $table_therapists");
?>

<div class="neoappointment-admin">
    <div class="neo-header">
        <h1>👩‍⚕️ اسکین تراپیست‌ها</h1>
        <button id="neo-add-therapist-btn" class="neo-btn neo-btn-primary">افزودن اسکین تراپیست جدید</button>
    </div>
    
    <div class="neo-content-section">
        <div class="neo-table-container">
            <table class="neo-table">
                <thead>
                    <tr>
                        <th>نام</th>
                        <th>ایمیل ۱</th>
                        <th>ایمیل ۲</th>
                        <th>ساعات کاری</th>
                        <th>مدت جلسه</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($therapists)): ?>
                        <tr>
                            <td colspan="6" class="neo-empty">هنوز اسکین تراپیستی اضافه نشده است</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($therapists as $therapist): ?>
                            <tr data-therapist='<?php echo json_encode($therapist); ?>'>
                                <td><?php echo esc_html($therapist->name); ?></td>
                                <td><?php echo esc_html($therapist->email1); ?></td>
                                <td><?php echo esc_html($therapist->email2); ?></td>
                                <td><?php echo esc_html($therapist->working_hours_start . ' - ' . $therapist->working_hours_end); ?></td>
                                <td><?php echo esc_html($therapist->session_duration); ?> دقیقه</td>
                                <td>
                                    <button class="neo-btn neo-btn-small neo-edit-therapist">ویرایش</button>
                                    <button class="neo-btn neo-btn-small neo-btn-danger neo-delete-therapist">حذف</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div id="neo-therapist-modal" class="neo-modal">
        <div class="neo-modal-content">
            <span class="neo-close">&times;</span>
            <h2 id="neo-therapist-modal-title">افزودن اسکین تراپیست</h2>
            <form id="neo-therapist-form">
                <input type="hidden" id="neo-therapist-id" name="id">
                
                <div class="neo-form-group">
                    <label>نام اسکین تراپیست</label>
                    <input type="text" id="neo-therapist-name" name="name" required>
                </div>
                
                <div class="neo-form-group">
                    <label>ایمیل ۱</label>
                    <input type="email" id="neo-therapist-email1" name="email1">
                </div>
                
                <div class="neo-form-group">
                    <label>ایمیل ۲</label>
                    <input type="email" id="neo-therapist-email2" name="email2">
                </div>
                
                <div class="neo-form-group">
                    <label>روز‌های کاری</label>
                    <div class="neo-checkboxes">
                        <label><input type="checkbox" name="working_days[]" value="0"> یکشنبه</label>
                        <label><input type="checkbox" name="working_days[]" value="1"> دوشنبه</label>
                        <label><input type="checkbox" name="working_days[]" value="2"> سه‌شنبه</label>
                        <label><input type="checkbox" name="working_days[]" value="3"> چهارشنبه</label>
                        <label><input type="checkbox" name="working_days[]" value="4"> پنجشنبه</label>
                        <label><input type="checkbox" name="working_days[]" value="5"> جمعه</label>
                        <label><input type="checkbox" name="working_days[]" value="6"> شنبه</label>
                    </div>
                </div>
                
                <div class="neo-form-row">
                    <div class="neo-form-group">
                        <label>ساعت شروع کار</label>
                        <input type="time" id="neo-therapist-start" name="working_hours_start" required>
                    </div>
                    <div class="neo-form-group">
                        <label>ساعت پایان کار</label>
                        <input type="time" id="neo-therapist-end" name="working_hours_end" required>
                    </div>
                </div>
                
                <div class="neo-form-group">
                    <label>مدت جلسه (دقیقه)</label>
                    <input type="number" id="neo-therapist-duration" name="session_duration" min="15" step="15" value="60" required>
                </div>
                
                <button type="submit" class="neo-btn neo-btn-primary">ذخیره</button>
            </form>
        </div>
    </div>
</div>
