<?php
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$table_blocked_days = $wpdb->prefix . 'neoappointment_blocked_days';
$blocked_days = $wpdb->get_results("SELECT * FROM $table_blocked_days ORDER BY blocked_date DESC");
?>

<div class="neoappointment-admin">
    <div class="neo-header">
        <h1>🚫 روز‌های تعطیل</h1>
        <button id="neo-add-blocked-day-btn" class="neo-btn neo-btn-primary">افزودن روز تعطیل</button>
    </div>
    
    <div class="neo-content-section">
        <div class="neo-table-container">
            <table class="neo-table">
                <thead>
                    <tr>
                        <th>تاریخ</th>
                        <th>دلیل</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($blocked_days)): ?>
                        <tr>
                            <td colspan="3" class="neo-empty">هنوز روز تعطیلی ثبت نشده است</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($blocked_days as $day): ?>
                            <tr data-blocked-day='<?php echo json_encode($day); ?>'>
                                <td><?php echo esc_html($day->blocked_date); ?></td>
                                <td><?php echo esc_html($day->reason); ?></td>
                                <td>
                                    <button class="neo-btn neo-btn-small neo-edit-blocked-day">ویرایش</button>
                                    <button class="neo-btn neo-btn-small neo-btn-danger neo-delete-blocked-day">حذف</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div id="neo-blocked-day-modal" class="neo-modal">
        <div class="neo-modal-content">
            <span class="neo-close">&times;</span>
            <h2 id="neo-blocked-day-modal-title">افزودن روز تعطیل</h2>
            <form id="neo-blocked-day-form">
                <input type="hidden" id="neo-blocked-day-id" name="id">
                
                <div class="neo-form-group">
                    <label>تاریخ</label>
                    <input type="date" id="neo-blocked-date" name="blocked_date" required>
                </div>
                
                <div class="neo-form-group">
                    <label>دلیل (اختیاری)</label>
                    <textarea id="neo-blocked-reason" name="reason"></textarea>
                </div>
                
                <button type="submit" class="neo-btn neo-btn-primary">ذخیره</button>
            </form>
        </div>
    </div>
</div>
