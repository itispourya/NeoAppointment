<?php
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$table_appointments = $wpdb->prefix . 'neoappointment_appointments';
$table_therapists = $wpdb->prefix . 'neoappointment_therapists';

$today = date('Y-m-d');
$today_appointments = $wpdb->get_results($wpdb->prepare(
    "SELECT a.*, t.name as therapist_name FROM $table_appointments a 
    LEFT JOIN $table_therapists t ON a.therapist_id = t.id 
    WHERE a.appointment_date = %s ORDER BY a.appointment_time",
    $today
));

$total_appointments = $wpdb->get_var("SELECT COUNT(*) FROM $table_appointments");
$total_therapists = $wpdb->get_var("SELECT COUNT(*) FROM $table_therapists");
?>

<div class="neoappointment-admin">
    <div class="neo-header">
        <h1>🚀 NeoAppointment - داشبورد</h1>
        <p>سیستم نوبت‌دهی مدرن و سه‌بعدی</p>
    </div>
    
    <div class="neo-stats">
        <div class="neo-stat-card">
            <div class="neo-stat-icon">📅</div>
            <div class="neo-stat-content">
                <h3><?php echo $total_appointments; ?></h3>
                <p>کل نوبت‌ها</p>
            </div>
        </div>
        <div class="neo-stat-card">
            <div class="neo-stat-icon">👩‍⚕️</div>
            <div class="neo-stat-content">
                <h3><?php echo $total_therapists; ?></h3>
                <p>اسکین تراپیست‌ها</p>
            </div>
        </div>
        <div class="neo-stat-card">
            <div class="neo-stat-icon">📋</div>
            <div class="neo-stat-content">
                <h3><?php echo count($today_appointments); ?></h3>
                <p>نوبت‌های امروز</p>
            </div>
        </div>
    </div>
    
    <div class="neo-content-section">
        <h2>نوبت‌های امروز</h2>
        <div class="neo-table-container">
            <table class="neo-table">
                <thead>
                    <tr>
                        <th>نام</th>
                        <th>تلفن</th>
                        <th>اسکین تراپیست</th>
                        <th>ساعت</th>
                        <th>وضعیت</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($today_appointments)): ?>
                        <tr>
                            <td colspan="5" class="neo-empty">نوبتی برای امروز ثبت نشده است</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($today_appointments as $appointment): ?>
                            <tr>
                                <td><?php echo esc_html($appointment->first_name . ' ' . $appointment->last_name); ?></td>
                                <td><?php echo esc_html($appointment->phone); ?></td>
                                <td><?php echo esc_html($appointment->therapist_name); ?></td>
                                <td><?php echo esc_html($appointment->appointment_time); ?></td>
                                <td>
                                    <span class="neo-status neo-status-<?php echo $appointment->status; ?>">
                                        <?php echo $appointment->status === 'completed' ? 'برگذار شد' : ($appointment->status === 'cancelled' ? 'لغو شد' : 'در انتظار'); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="neo-content-section">
        <h2>تقویم نوبت‌ها</h2>
        <div id="neo-calendar-debug" style="background: rgba(0,255,0,0.2); padding: 10px; margin-bottom: 10px; border-radius: 5px;">
            <strong>تست تقویم:</strong> اگر این متن را می‌بینید، کانتینر ها در حال بارگذاری هستند.
        </div>
        <div class="neo-calendar-container">
            <div class="neo-calendar-nav">
                <button id="neo-prev-month" class="neo-btn">ماه قبل</button>
                <h3 id="neo-current-month" style="color: #00d2ff; font-size: 20px; border: 1px dashed #00d2ff; padding: 5px;">نام ماه اینجا نمایش داده می‌شود</h3>
                <button id="neo-next-month" class="neo-btn">ماه بعد</button>
            </div>
            <div id="neo-calendar" class="neo-calendar" style="border: 2px dashed #ff0000; min-height: 200px;"></div>
        </div>
    </div>
    
    <div id="neo-appointment-modal" class="neo-modal">
        <div class="neo-modal-content">
            <span class="neo-close">&times;</span>
            <h2>نوبت‌های این روز</h2>
            <div id="neo-appointments-list"></div>
        </div>
    </div>
</div>
