<?php
if (!defined('ABSPATH')) {
    exit;
}

// Get therapists
global $wpdb;
$table_therapists = $wpdb->prefix . 'neoappointment_therapists';

// If shortcode ID is provided, get assigned therapists
$therapist_ids = array();
if (isset($shortcode_id) && !empty($shortcode_id)) {
    $table_shortcodes = $wpdb->prefix . 'neoappointment_shortcodes';
    $shortcode = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_shortcodes WHERE id = %d", $shortcode_id));
    if ($shortcode && !empty($shortcode->therapist_ids)) {
        $therapist_ids = json_decode($shortcode->therapist_ids, true);
    }
}

// Prepare therapist query
$where = '';
if (!empty($therapist_ids)) {
    $placeholders = implode(',', array_fill(0, count($therapist_ids), '%d'));
    $where = $wpdb->prepare(" WHERE id IN ($placeholders)", ...$therapist_ids);
}

$therapists = $wpdb->get_results("SELECT * FROM $table_therapists $where ORDER BY name ASC");
?>

<div class="neoappointment-frontend" data-shortcode-id="<?php echo isset($shortcode_id) ? esc_attr($shortcode_id) : ''; ?>">
    <div class="neo-booking-container">
        <div class="neo-booking-header">
            <h1>نوبت دهی آنلاین</h1>
            <p>فرم زیر را پر کرده و نوبت خود را رزرو کنید</p>
        </div>
        
        <form id="neo-booking-form" class="neo-booking-form">
            <div class="neo-form-group">
                <label for="neo-booking-therapist">اسکین تراپیست</label>
                <select id="neo-booking-therapist" name="therapist_id" required>
                    <option value="">انتخاب کنید</option>
                    <?php foreach ($therapists as $therapist): ?>
                        <option value="<?php echo esc_attr($therapist->id); ?>"><?php echo esc_html($therapist->name); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="neo-form-row">
                <div class="neo-form-group">
                    <label for="neo-booking-firstname">نام</label>
                    <input type="text" id="neo-booking-firstname" name="first_name" required>
                </div>
                <div class="neo-form-group">
                    <label for="neo-booking-lastname">نام خانوادگی</label>
                    <input type="text" id="neo-booking-lastname" name="last_name" required>
                </div>
            </div>
            
            <div class="neo-form-group">
                <label for="neo-booking-phone">شماره تماس</label>
                <input type="tel" id="neo-booking-phone" name="phone" required>
            </div>
            
            <div class="neo-form-group">
                <label for="neo-booking-service">نوع خدمت (اختیاری)</label>
                <textarea id="neo-booking-service" name="service_type" rows="3"></textarea>
            </div>
            
            <div class="neo-form-row">
                <div class="neo-form-group">
                    <label for="neo-booking-year">سال</label>
                    <select id="neo-booking-year" required>
                        <option value="">انتخاب کنید</option>
                    </select>
                </div>
                <div class="neo-form-group">
                    <label for="neo-booking-month">ماه</label>
                    <select id="neo-booking-month" required disabled>
                        <option value="">انتخاب کنید</option>
                    </select>
                </div>
            </div>
            
            <div class="neo-form-group">
                <label for="neo-booking-day">روز</label>
                <select id="neo-booking-day" required disabled>
                    <option value="">انتخاب کنید</option>
                </select>
            </div>
            
            <div class="neo-form-group">
                <label for="neo-booking-time">ساعت</label>
                <select id="neo-booking-time" name="appointment_time" required disabled>
                    <option value="">ابتدا اسکین تراپیست و تاریخ را انتخاب کنید</option>
                </select>
            </div>
            
            <input type="hidden" id="neo-booking-date" name="appointment_date">
            
            <div class="neo-message" id="neo-booking-message" style="display: none;"></div>
            
            <button type="submit" class="neo-btn neo-btn-primary">ثبت نوبت</button>
        </form>
    </div>
</div>
