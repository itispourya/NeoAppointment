<?php
if (!defined('ABSPATH')) {
    exit;
}

class NeoAppointment_Frontend {
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('wp_ajax_nopriv_neoappointment_book_appointment', array($this, 'book_appointment'));
        add_action('wp_ajax_neoappointment_book_appointment', array($this, 'book_appointment'));
        add_action('wp_ajax_nopriv_neoappointment_get_therapists', array($this, 'get_therapists'));
        add_action('wp_ajax_neoappointment_get_therapists', array($this, 'get_therapists'));
        add_action('wp_ajax_nopriv_neoappointment_get_available_times', array($this, 'get_available_times'));
        add_action('wp_ajax_neoappointment_get_available_times', array($this, 'get_available_times'));
        add_action('wp_ajax_nopriv_neoappointment_get_available_days', array($this, 'get_available_days'));
        add_action('wp_ajax_neoappointment_get_available_days', array($this, 'get_available_days'));
    }
    
    public function enqueue_frontend_assets() {
        wp_enqueue_style('neoappointment-frontend-css', NEOAPPOINTMENT_PLUGIN_URL . 'assets/css/frontend.css', array(), NEOAPPOINTMENT_VERSION);
        wp_enqueue_script('jalaali-js', NEOAPPOINTMENT_PLUGIN_URL . 'assets/js/jalaali.js', array(), NEOAPPOINTMENT_VERSION, true);
        wp_enqueue_script('neoappointment-frontend-js', NEOAPPOINTMENT_PLUGIN_URL . 'assets/js/frontend.js', array('jquery', 'jalaali-js'), NEOAPPOINTMENT_VERSION, true);
        
        wp_localize_script('neoappointment-frontend-js', 'neoappointment_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('neoappointment_nonce')
        ));
        
        // Add custom colors CSS
        add_action('wp_head', array($this, 'add_custom_colors_css'));
    }
    
    public function add_custom_colors_css() {
        global $wpdb;
        $table_settings = $wpdb->prefix . 'neoappointment_settings';
        $settings = $wpdb->get_results("SELECT * FROM $table_settings");
        
        $colors = array(
            'color_bg_primary' => '#0f0c29',
            'color_bg_secondary' => '#302b63',
            'color_bg_tertiary' => '#24243e',
            'color_text_primary' => '#00d2ff',
            'color_text_secondary' => '#3a7bd5',
            'color_btn_primary_1' => '#667eea',
            'color_btn_primary_2' => '#764ba2',
            'color_btn_secondary_1' => '#00d2ff',
            'color_btn_secondary_2' => '#3a7bd5',
            'color_success' => '#4caf50',
            'color_error' => '#f44336',
            'color_text' => '#ffffff',
            'color_input_bg' => 'rgba(255,255,255,0.1)',
            'color_select_bg' => 'rgba(255,255,255,0.1)'
        );
        
        foreach ($settings as $setting) {
            if (isset($colors[$setting->setting_key])) {
                $colors[$setting->setting_key] = $setting->setting_value;
            }
        }
        
        ?>
        <style>
            .neoappointment-frontend {
                background: linear-gradient(135deg, <?php echo $colors['color_bg_primary']; ?> 0%, <?php echo $colors['color_bg_secondary']; ?> 50%, <?php echo $colors['color_bg_tertiary']; ?> 100%) !important;
            }
            
            .neo-booking-header h1 {
                background: linear-gradient(90deg, <?php echo $colors['color_text_primary']; ?>, <?php echo $colors['color_text_secondary']; ?>) !important;
                -webkit-background-clip: text !important;
                -webkit-text-fill-color: transparent !important;
                background-clip: text !important;
            }
            
            .neo-form-group label {
                color: <?php echo $colors['color_text_primary']; ?> !important;
            }
            
            .neo-form-group input,
            .neo-form-group textarea {
                background: <?php echo $colors['color_input_bg']; ?> !important;
            }
            
            .neo-form-group select {
                background: <?php echo $colors['color_select_bg']; ?> !important;
            }
            
            .neo-form-group input:focus,
            .neo-form-group select:focus,
            .neo-form-group textarea:focus {
                border-color: <?php echo $colors['color_text_primary']; ?> !important;
                box-shadow: 0 0 25px rgba(<?php echo $this->hex_to_rgb($colors['color_text_primary']); ?>, 0.4) !important;
            }
            
            .neo-btn {
                background: linear-gradient(135deg, <?php echo $colors['color_btn_primary_1']; ?> 0%, <?php echo $colors['color_btn_primary_2']; ?> 100%) !important;
                box-shadow: 0 4px 15px rgba(<?php echo $this->hex_to_rgb($colors['color_btn_primary_1']); ?>, 0.4) !important;
            }
            
            .neo-btn:hover {
                box-shadow: 0 8px 25px rgba(<?php echo $this->hex_to_rgb($colors['color_btn_primary_1']); ?>, 0.6) !important;
            }
            
            .neo-btn-primary {
                background: linear-gradient(135deg, <?php echo $colors['color_btn_secondary_1']; ?> 0%, <?php echo $colors['color_btn_secondary_2']; ?> 100%) !important;
                box-shadow: 0 4px 15px rgba(<?php echo $this->hex_to_rgb($colors['color_btn_secondary_1']); ?>, 0.4) !important;
            }
            
            .neo-btn-primary:hover {
                box-shadow: 0 8px 25px rgba(<?php echo $this->hex_to_rgb($colors['color_btn_secondary_1']); ?>, 0.6) !important;
            }
            
            .neo-message.success {
                background: rgba(<?php echo $this->hex_to_rgb($colors['color_success']); ?>, 0.2) !important;
                border: 1px solid <?php echo $colors['color_success']; ?> !important;
                color: <?php echo $colors['color_success']; ?> !important;
            }
            
            .neo-message.error {
                background: rgba(<?php echo $this->hex_to_rgb($colors['color_error']); ?>, 0.2) !important;
                border: 1px solid <?php echo $colors['color_error']; ?> !important;
                color: <?php echo $colors['color_error']; ?> !important;
            }
            
            .neo-form-group input,
            .neo-form-group select,
            .neo-form-group textarea,
            .neo-booking-header p,
            .neo-message {
                color: <?php echo $colors['color_text']; ?> !important;
            }
            
            .neo-booking-container {
                background: rgba(255, 255, 255, 0.05) !important;
                border: 1px solid rgba(255, 255, 255, 0.1) !important;
            }
        </style>
        <?php
    }
    
    private function parse_color($color) {
        $color = trim($color);
        
        // Check for RGB/RGBA
        if (stripos($color, 'rgb') === 0) {
            // Extract numbers
            preg_match('/rgba?\s*\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*([\d.]+))?\s*\)/i', $color, $matches);
            if (count($matches) >= 4) {
                $r = intval($matches[1]);
                $g = intval($matches[2]);
                $b = intval($matches[3]);
                $a = isset($matches[4]) ? floatval($matches[4]) : 1;
                return array('r' => $r, 'g' => $g, 'b' => $b, 'a' => $a, 'original' => $color);
            }
        }
        
        // Handle HEX
        $hex = ltrim($color, '#');
        $r = 0; $g = 0; $b = 0; $a = 1;
        
        switch(strlen($hex)) {
            case 3: // #RGB
                $r = hexdec($hex[0].$hex[0]);
                $g = hexdec($hex[1].$hex[1]);
                $b = hexdec($hex[2].$hex[2]);
                break;
            case 4: // #RGBA
                $r = hexdec($hex[0].$hex[0]);
                $g = hexdec($hex[1].$hex[1]);
                $b = hexdec($hex[2].$hex[2]);
                $a = round(hexdec($hex[3].$hex[3]) / 255, 2);
                break;
            case 6: // #RRGGBB
                $r = hexdec(substr($hex, 0, 2));
                $g = hexdec(substr($hex, 2, 2));
                $b = hexdec(substr($hex, 4, 2));
                break;
            case 8: // #RRGGBBAA
                $r = hexdec(substr($hex, 0, 2));
                $g = hexdec(substr($hex, 2, 2));
                $b = hexdec(substr($hex, 4, 2));
                $a = round(hexdec(substr($hex, 6, 2)) / 255, 2);
                break;
        }
        
        return array('r' => $r, 'g' => $g, 'b' => $b, 'a' => $a, 'original' => $color);
    }
    
    private function hex_to_rgb($hex) {
        $parsed = $this->parse_color($hex);
        return "{$parsed['r']}, {$parsed['g']}, {$parsed['b']}";
    }
    
    private function hex_to_rgba($hex, $alpha = null) {
        $parsed = $this->parse_color($hex);
        $a = $alpha !== null ? $alpha : $parsed['a'];
        return "{$parsed['r']}, {$parsed['g']}, {$parsed['b']}, $a";
    }
    
    public function get_therapists() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $shortcode_id = isset($_POST['shortcode_id']) ? intval($_POST['shortcode_id']) : 0;
        
        if ($shortcode_id) {
            $shortcode = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}neoappointment_shortcodes WHERE id = %d",
                $shortcode_id
            ));
            
            if ($shortcode) {
                $therapist_ids = maybe_unserialize($shortcode->therapist_ids);
                if ($therapist_ids && is_array($therapist_ids)) {
                    $placeholders = implode(',', array_fill(0, count($therapist_ids), '%d'));
                    $therapists = $wpdb->get_results($wpdb->prepare(
                        "SELECT * FROM {$wpdb->prefix}neoappointment_therapists WHERE id IN ($placeholders)",
                        $therapist_ids
                    ));
                }
            }
        }
        
        if (empty($therapists)) {
            $therapists = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}neoappointment_therapists");
        }
        
        wp_send_json_success($therapists);
    }
    
    public function get_available_times() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $therapist_id = intval($_POST['therapist_id']);
        $date = sanitize_text_field($_POST['date']);
        
        $therapist = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}neoappointment_therapists WHERE id = %d",
            $therapist_id
        ));
        
        if (!$therapist) {
            wp_send_json_error();
        }
        
        $blocked_day = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}neoappointment_blocked_days WHERE blocked_date = %s",
            $date
        ));
        
        if ($blocked_day) {
            wp_send_json_success(array());
        }
        
        $working_days = maybe_unserialize($therapist->working_days);
        $day_of_week = date('w', strtotime($date));
        
        if (!in_array($day_of_week, $working_days)) {
            wp_send_json_success(array());
        }
        
        $appointments = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}neoappointment_appointments 
            WHERE therapist_id = %d AND appointment_date = %s AND status != 'cancelled'",
            $therapist_id,
            $date
        ));
        
        $available_times = array();
        $start = strtotime($therapist->working_hours_start);
        $end = strtotime($therapist->working_hours_end);
        $duration = $therapist->session_duration * 60;
        
        while ($start < $end) {
            $time = date('H:i', $start);
            $is_available = true;
            
            foreach ($appointments as $appointment) {
                $appt_start = strtotime($appointment->appointment_time);
                $appt_end = $appt_start + ($appointment->duration * 60);
                
                if ($start >= $appt_start && $start < $appt_end) {
                    $is_available = false;
                    break;
                }
            }
            
            if ($is_available) {
                $available_times[] = $time;
            }
            
            $start += $duration;
        }
        
        wp_send_json_success($available_times);
    }
    
    public function get_available_days() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $therapist_id = intval($_POST['therapist_id']);
        $jalali_year = intval($_POST['jalali_year']);
        $jalali_month = intval($_POST['jalali_month']);
        $days_in_month = intval($_POST['days_in_month']);
        
        $therapist = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}neoappointment_therapists WHERE id = %d",
            $therapist_id
        ));
        
        if (!$therapist) {
            wp_send_json_error();
        }
        
        $working_days = maybe_unserialize($therapist->working_days);
        $available_days = array();
        $today = new DateTime();
        $today->setTime(0, 0, 0);
        
        for ($day = 1; $day <= $days_in_month; $day++) {
            // Convert Jalali to Gregorian
            $jy = $jalali_year;
            $jm = $jalali_month;
            $jd = $day;
            
            // Simple Jalali to Gregorian conversion (we'll do this with PHP)
            $gregorian = $this->jalali_to_gregorian($jy, $jm, $jd);
            $date_str = sprintf('%04d-%02d-%02d', $gregorian[0], $gregorian[1], $gregorian[2]);
            $date_obj = new DateTime($date_str);
            
            // Check if date is in the past
            if ($date_obj < $today) {
                continue;
            }
            
            // Check if day is blocked
            $blocked = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}neoappointment_blocked_days WHERE blocked_date = %s",
                $date_str
            ));
            
            if ($blocked) {
                continue;
            }
            
            // Check if day is in working days
            $day_of_week = intval($date_obj->format('w'));
            if (!in_array($day_of_week, $working_days)) {
                continue;
            }
            
            $available_days[] = $day;
        }
        
        wp_send_json_success(array('available_days' => $available_days));
    }
    
    private function jalali_to_gregorian($jy, $jm, $jd) {
        $gy = $jy + 621;
        $days_in_month = ($jm <= 6) ? 31 : 30;
        
        $j_days = ($jm - 1) * 31 - (($jm > 6) ? ($jm - 6) : 0) + $jd - 1;
        $g_days = $j_days + 79; // March 21 is day 79
        
        $g_year = $gy;
        $month_days = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
        
        if (($g_year % 4 == 0 && $g_year % 100 != 0) || ($g_year % 400 == 0)) {
            $month_days[1] = 29;
        }
        
        $g_month = 0;
        while ($g_days >= $month_days[$g_month]) {
            $g_days -= $month_days[$g_month];
            $g_month++;
        }
        
        return array($g_year, $g_month + 1, $g_days + 1);
    }
    
    public function book_appointment() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $table_appointments = $wpdb->prefix . 'neoappointment_appointments';
        $table_settings = $wpdb->prefix . 'neoappointment_settings';
        
        $therapist_id = intval($_POST['therapist_id']);
        $appointment_date = sanitize_text_field($_POST['appointment_date']);
        $appointment_time = sanitize_text_field($_POST['appointment_time']);
        
        $therapist = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}neoappointment_therapists WHERE id = %d",
            $therapist_id
        ));
        
        $conflict = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_appointments 
            WHERE therapist_id = %d AND appointment_date = %s AND appointment_time = %s AND status != 'cancelled'",
            $therapist_id,
            $appointment_date,
            $appointment_time
        ));
        
        if ($conflict) {
            $message = $wpdb->get_var($wpdb->prepare("SELECT setting_value FROM $table_settings WHERE setting_key = %s", 'time_conflict_message'));
            wp_send_json_error(array('message' => $message ? $message : 'این زمان قبلاً رزرو شده است.'));
        }
        
        $data = array(
            'therapist_id' => $therapist_id,
            'first_name' => sanitize_text_field($_POST['first_name']),
            'last_name' => sanitize_text_field($_POST['last_name']),
            'phone' => sanitize_text_field($_POST['phone']),
            'service_type' => sanitize_textarea_field($_POST['service_type']),
            'appointment_date' => $appointment_date,
            'appointment_time' => $appointment_time,
            'duration' => $therapist->session_duration,
            'status' => 'pending'
        );
        
        $wpdb->insert($table_appointments, $data);
        $appointment_id = $wpdb->insert_id;
        
        $this->send_notifications($appointment_id);
        
        $success_message = $wpdb->get_var($wpdb->prepare("SELECT setting_value FROM $table_settings WHERE setting_key = %s", 'success_message'));
        
        wp_send_json_success(array('message' => $success_message ? $success_message : 'نوبت شما با موفقیت ثبت شد.'));
    }
    
    private function send_notifications($appointment_id) {
        global $wpdb;
        
        $appointment = $wpdb->get_row($wpdb->prepare(
            "SELECT a.*, t.name as therapist_name, t.email1, t.email2 
            FROM {$wpdb->prefix}neoappointment_appointments a
            JOIN {$wpdb->prefix}neoappointment_therapists t ON a.therapist_id = t.id
            WHERE a.id = %d",
            $appointment_id
        ));
        
        if (!$appointment) {
            return;
        }
        
        $admin_email = $wpdb->get_var("SELECT setting_value FROM {$wpdb->prefix}neoappointment_settings WHERE setting_key = 'admin_email'");
        
        $subject = 'نوبت جدید ثبت شد';
        $message = "نوبت جدیدی ثبت شد:\n\n";
        $message .= "نام: {$appointment->first_name} {$appointment->last_name}\n";
        $message .= "تلفن: {$appointment->phone}\n";
        $message .= "اسکین تراپیست: {$appointment->therapist_name}\n";
        $message .= "تاریخ: {$appointment->appointment_date}\n";
        $message .= "ساعت: {$appointment->appointment_time}\n";
        $message .= "نوع خدمت: {$appointment->service_type}\n";
        
        $headers = array('Content-Type: text/plain; charset=UTF-8');
        
        if ($admin_email) {
            wp_mail($admin_email, $subject, $message, $headers);
        }
        
        if ($appointment->email1) {
            wp_mail($appointment->email1, $subject, $message, $headers);
        }
        
        if ($appointment->email2) {
            wp_mail($appointment->email2, $subject, $message, $headers);
        }
    }
}
