<?php
if (!defined('ABSPATH')) {
    exit;
}

class NeoAppointment_Database {
    public static function install() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        $table_appointments = $wpdb->prefix . 'neoappointment_appointments';
        $table_therapists = $wpdb->prefix . 'neoappointment_therapists';
        $table_blocked_days = $wpdb->prefix . 'neoappointment_blocked_days';
        $table_shortcodes = $wpdb->prefix . 'neoappointment_shortcodes';
        $table_settings = $wpdb->prefix . 'neoappointment_settings';
        
        $sql_appointments = "CREATE TABLE $table_appointments (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            therapist_id bigint(20) NOT NULL,
            first_name varchar(100) NOT NULL,
            last_name varchar(100) NOT NULL,
            phone varchar(20) NOT NULL,
            service_type text,
            appointment_date date NOT NULL,
            appointment_time time NOT NULL,
            duration int(11) NOT NULL DEFAULT 60,
            status varchar(20) DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY therapist_id (therapist_id),
            KEY appointment_date (appointment_date)
        ) $charset_collate;";
        
        $sql_therapists = "CREATE TABLE $table_therapists (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            email1 varchar(100),
            email2 varchar(100),
            working_days text NOT NULL,
            working_hours_start time NOT NULL,
            working_hours_end time NOT NULL,
            session_duration int(11) NOT NULL DEFAULT 60,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        $sql_blocked_days = "CREATE TABLE $table_blocked_days (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            blocked_date date NOT NULL,
            reason text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY blocked_date (blocked_date)
        ) $charset_collate;";
        
        $sql_shortcodes = "CREATE TABLE $table_shortcodes (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            therapist_ids text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        $sql_settings = "CREATE TABLE $table_settings (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            setting_key varchar(100) NOT NULL,
            setting_value text,
            PRIMARY KEY  (id),
            UNIQUE KEY setting_key (setting_key)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_appointments);
        dbDelta($sql_therapists);
        dbDelta($sql_blocked_days);
        dbDelta($sql_shortcodes);
        dbDelta($sql_settings);
        
        self::insert_default_settings();
    }
    
    public static function uninstall() {
        global $wpdb;
        $tables = array(
            $wpdb->prefix . 'neoappointment_appointments',
            $wpdb->prefix . 'neoappointment_therapists',
            $wpdb->prefix . 'neoappointment_blocked_days',
            $wpdb->prefix . 'neoappointment_shortcodes',
            $wpdb->prefix . 'neoappointment_settings'
        );
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
    }
    
    private static function insert_default_settings() {
        global $wpdb;
        $table_settings = $wpdb->prefix . 'neoappointment_settings';
        
        $default_settings = array(
            'admin_email' => get_option('admin_email'),
            'success_message' => 'نوبت شما ثبت شد. لطفاً 15 دقیقه قبل از زمان ثبت شده در محل حضور داشته باشید.',
            'error_message' => 'متأسفانه خطایی رخ داده است. لطفاً دوباره تلاش کنید.',
            'time_conflict_message' => 'این زمان قبلاً رزرو شده است. لطفاً زمان دیگری انتخاب کنید.',
            'color_bg_primary' => '#0f0c29',
            'color_bg_secondary' => '#302b63',
            'color_bg_tertiary' => '#24243e',
            'color_text_primary' => '#00d2ff',
            'color_text_secondary' => '#3a7bd5',
            'color_btn_primary_1' => '#667eea',
            'color_btn_primary_2' => '#764ba2',
            'color_btn_secondary_1' => '#00d2ff',
            'color_btn_secondary_2' => '#3a7bd5',
            'color_success' => '#4caf50',
            'color_error' => '#f44336',
            'color_text' => '#ffffff'
        );
        
        foreach ($default_settings as $key => $value) {
            $wpdb->replace($table_settings, array(
                'setting_key' => $key,
                'setting_value' => $value
            ));
        }
    }
}
