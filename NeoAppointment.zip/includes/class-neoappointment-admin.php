<?php
if (!defined('ABSPATH')) {
    exit;
}

class NeoAppointment_Admin {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('wp_ajax_neoappointment_save_therapist', array($this, 'save_therapist'));
        add_action('wp_ajax_neoappointment_delete_therapist', array($this, 'delete_therapist'));
        add_action('wp_ajax_neoappointment_save_appointment', array($this, 'save_appointment'));
        add_action('wp_ajax_neoappointment_delete_appointment', array($this, 'delete_appointment'));
        add_action('wp_ajax_neoappointment_save_blocked_day', array($this, 'save_blocked_day'));
        add_action('wp_ajax_neoappointment_delete_blocked_day', array($this, 'delete_blocked_day'));
        add_action('wp_ajax_neoappointment_save_shortcode', array($this, 'save_shortcode'));
        add_action('wp_ajax_neoappointment_delete_shortcode', array($this, 'delete_shortcode'));
        add_action('wp_ajax_neoappointment_save_settings', array($this, 'save_settings'));
        add_action('wp_ajax_neoappointment_get_appointments', array($this, 'get_appointments'));
        add_action('wp_ajax_neoappointment_get_available_times', array($this, 'get_available_times'));
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'NeoAppointment',
            'NeoAppointment',
            'manage_options',
            'neoappointment',
            array($this, 'render_admin_dashboard'),
            'dashicons-calendar-alt',
            25
        );
        
        add_submenu_page(
            'neoappointment',
            'داشبورد',
            'داشبورد',
            'manage_options',
            'neoappointment',
            array($this, 'render_admin_dashboard')
        );
        
        add_submenu_page(
            'neoappointment',
            'اسکین تراپیست‌ها',
            'اسکین تراپیست‌ها',
            'manage_options',
            'neoappointment-therapists',
            array($this, 'render_therapists_page')
        );
        
        add_submenu_page(
            'neoappointment',
            'نوبت‌ها',
            'نوبت‌ها',
            'manage_options',
            'neoappointment-appointments',
            array($this, 'render_appointments_page')
        );
        
        add_submenu_page(
            'neoappointment',
            'روز‌های تعطیل',
            'روز‌های تعطیل',
            'manage_options',
            'neoappointment-blocked-days',
            array($this, 'render_blocked_days_page')
        );
        
        add_submenu_page(
            'neoappointment',
            'شورت‌کدها',
            'شورت‌کدها',
            'manage_options',
            'neoappointment-shortcodes',
            array($this, 'render_shortcodes_page')
        );
        
        add_submenu_page(
            'neoappointment',
            'تنظیمات',
            'تنظیمات',
            'manage_options',
            'neoappointment-settings',
            array($this, 'render_settings_page')
        );
    }
    
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'neoappointment') === false) {
            return;
        }
        
        wp_enqueue_style('neoappointment-admin-css', NEOAPPOINTMENT_PLUGIN_URL . 'assets/css/admin.css', array(), NEOAPPOINTMENT_VERSION);
        wp_enqueue_script('jalaali-js', NEOAPPOINTMENT_PLUGIN_URL . 'assets/js/jalaali.js', array(), NEOAPPOINTMENT_VERSION, false);
        wp_enqueue_script('neoappointment-admin-js', NEOAPPOINTMENT_PLUGIN_URL . 'assets/js/admin.js', array('jquery', 'jquery-ui-datepicker', 'jalaali-js'), NEOAPPOINTMENT_VERSION, true);
        
        wp_localize_script('neoappointment-admin-js', 'neoappointment_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('neoappointment_nonce')
        ));
        
        wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
    }
    
    public function render_admin_dashboard() {
        include NEOAPPOINTMENT_PLUGIN_DIR . 'admin/pages/dashboard.php';
    }
    
    public function render_therapists_page() {
        include NEOAPPOINTMENT_PLUGIN_DIR . 'admin/pages/therapists.php';
    }
    
    public function render_appointments_page() {
        include NEOAPPOINTMENT_PLUGIN_DIR . 'admin/pages/appointments.php';
    }
    
    public function render_blocked_days_page() {
        include NEOAPPOINTMENT_PLUGIN_DIR . 'admin/pages/blocked-days.php';
    }
    
    public function render_shortcodes_page() {
        include NEOAPPOINTMENT_PLUGIN_DIR . 'admin/pages/shortcodes.php';
    }
    
    public function render_settings_page() {
        include NEOAPPOINTMENT_PLUGIN_DIR . 'admin/pages/settings.php';
    }
    
    public function save_therapist() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $table = $wpdb->prefix . 'neoappointment_therapists';
        
        $data = array(
            'name' => sanitize_text_field($_POST['name']),
            'email1' => sanitize_email($_POST['email1']),
            'email2' => sanitize_email($_POST['email2']),
            'working_days' => maybe_serialize($_POST['working_days']),
            'working_hours_start' => sanitize_text_field($_POST['working_hours_start']),
            'working_hours_end' => sanitize_text_field($_POST['working_hours_end']),
            'session_duration' => intval($_POST['session_duration'])
        );
        
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            $wpdb->update($table, $data, array('id' => intval($_POST['id'])));
        } else {
            $wpdb->insert($table, $data);
        }
        
        wp_send_json_success();
    }
    
    public function delete_therapist() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $table = $wpdb->prefix . 'neoappointment_therapists';
        $wpdb->delete($table, array('id' => intval($_POST['id'])));
        
        wp_send_json_success();
    }
    
    public function save_appointment() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $table = $wpdb->prefix . 'neoappointment_appointments';
        
        $data = array(
            'therapist_id' => intval($_POST['therapist_id']),
            'first_name' => sanitize_text_field($_POST['first_name']),
            'last_name' => sanitize_text_field($_POST['last_name']),
            'phone' => sanitize_text_field($_POST['phone']),
            'service_type' => sanitize_textarea_field($_POST['service_type']),
            'appointment_date' => sanitize_text_field($_POST['appointment_date']),
            'appointment_time' => sanitize_text_field($_POST['appointment_time']),
            'duration' => intval($_POST['duration']),
            'status' => sanitize_text_field($_POST['status'])
        );
        
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            $wpdb->update($table, $data, array('id' => intval($_POST['id'])));
        } else {
            $wpdb->insert($table, $data);
        }
        
        wp_send_json_success();
    }
    
    public function delete_appointment() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $table = $wpdb->prefix . 'neoappointment_appointments';
        $wpdb->delete($table, array('id' => intval($_POST['id'])));
        
        wp_send_json_success();
    }
    
    public function save_blocked_day() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $table = $wpdb->prefix . 'neoappointment_blocked_days';
        
        $data = array(
            'blocked_date' => sanitize_text_field($_POST['blocked_date']),
            'reason' => sanitize_textarea_field($_POST['reason'])
        );
        
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            $wpdb->update($table, $data, array('id' => intval($_POST['id'])));
        } else {
            $wpdb->insert($table, $data);
        }
        
        wp_send_json_success();
    }
    
    public function delete_blocked_day() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $table = $wpdb->prefix . 'neoappointment_blocked_days';
        $wpdb->delete($table, array('id' => intval($_POST['id'])));
        
        wp_send_json_success();
    }
    
    public function save_shortcode() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $table = $wpdb->prefix . 'neoappointment_shortcodes';
        
        $data = array(
            'name' => sanitize_text_field($_POST['name']),
            'therapist_ids' => maybe_serialize($_POST['therapist_ids'])
        );
        
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            $wpdb->update($table, $data, array('id' => intval($_POST['id'])));
        } else {
            $wpdb->insert($table, $data);
        }
        
        wp_send_json_success();
    }
    
    public function delete_shortcode() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $table = $wpdb->prefix . 'neoappointment_shortcodes';
        $wpdb->delete($table, array('id' => intval($_POST['id'])));
        
        wp_send_json_success();
    }
    
    public function save_settings() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $table = $wpdb->prefix . 'neoappointment_settings';
        
        foreach ($_POST['settings'] as $key => $value) {
            $wpdb->replace($table, array(
                'setting_key' => sanitize_text_field($key),
                'setting_value' => sanitize_textarea_field($value)
            ));
        }
        
        wp_send_json_success();
    }
    
    public function get_appointments() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $table = $wpdb->prefix . 'neoappointment_appointments';
        
        if (isset($_POST['date']) && !empty($_POST['date'])) {
            $date = sanitize_text_field($_POST['date']);
            $appointments = $wpdb->get_results($wpdb->prepare(
                "SELECT a.*, t.name as therapist_name FROM $table a 
                LEFT JOIN {$wpdb->prefix}neoappointment_therapists t ON a.therapist_id = t.id 
                WHERE a.appointment_date = %s
                ORDER BY a.appointment_time ASC",
                $date
            ));
        } else {
            // Load all future appointments by default
            $today = date('Y-m-d');
            $appointments = $wpdb->get_results(
                "SELECT a.*, t.name as therapist_name FROM $table a 
                LEFT JOIN {$wpdb->prefix}neoappointment_therapists t ON a.therapist_id = t.id 
                WHERE a.appointment_date >= '$today'
                ORDER BY a.appointment_date ASC, a.appointment_time ASC"
            );
        }
        
        wp_send_json_success($appointments);
    }
    
    public function get_available_times() {
        check_ajax_referer('neoappointment_nonce', 'nonce');
        
        global $wpdb;
        $therapist_id = intval($_POST['therapist_id']);
        $date = sanitize_text_field($_POST['date']);
        
        $therapist = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}neoappointment_therapists WHERE id = %d",
            $therapist_id
        ));
        
        if (!$therapist) {
            wp_send_json_error();
        }
        
        $blocked_day = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}neoappointment_blocked_days WHERE blocked_date = %s",
            $date
        ));
        
        if ($blocked_day) {
            wp_send_json_success(array());
        }
        
        $working_days = maybe_unserialize($therapist->working_days);
        $day_of_week = date('w', strtotime($date));
        
        if (!in_array($day_of_week, $working_days)) {
            wp_send_json_success(array());
        }
        
        $appointments = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}neoappointment_appointments 
            WHERE therapist_id = %d AND appointment_date = %s AND status != 'cancelled'",
            $therapist_id,
            $date
        ));
        
        $available_times = array();
        $start = strtotime($therapist->working_hours_start);
        $end = strtotime($therapist->working_hours_end);
        $duration = $therapist->session_duration * 60;
        
        while ($start < $end) {
            $time = date('H:i', $start);
            $is_available = true;
            
            foreach ($appointments as $appointment) {
                $appt_start = strtotime($appointment->appointment_time);
                $appt_end = $appt_start + ($appointment->duration * 60);
                
                if ($start >= $appt_start && $start < $appt_end) {
                    $is_available = false;
                    break;
                }
            }
            
            if ($is_available) {
                $available_times[] = $time;
            }
            
            $start += $duration;
        }
        
        wp_send_json_success($available_times);
    }
    
    public static function extract_hex_for_picker($color) {
        $color = trim($color);
        
        // If it's already a valid hex for picker (3 or 6 digits), return it
        if (preg_match('/^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $color, $matches)) {
            return '#' . str_pad($matches[1], 6, $matches[1][0], STR_PAD_LEFT);
        }
        
        // Try to parse RGB/RGBA to hex
        if (preg_match('/rgba?\s*\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})/', $color, $matches)) {
            $r = min(255, max(0, intval($matches[1])));
            $g = min(255, max(0, intval($matches[2])));
            $b = min(255, max(0, intval($matches[3])));
            return sprintf('#%02x%02x%02x', $r, $g, $b);
        }
        
        // Default fallback
        return '#000000';
    }
}
