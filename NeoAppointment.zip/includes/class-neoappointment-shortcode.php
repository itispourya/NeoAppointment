<?php
if (!defined('ABSPATH')) {
    exit;
}

class NeoAppointment_Shortcode {
    public function __construct() {
        add_shortcode('neoappointment', array($this, 'render_shortcode'));
    }
    
    public function render_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => 0
        ), $atts);
        
        $shortcode_id = intval($atts['id']);
        
        ob_start();
        include NEOAPPOINTMENT_PLUGIN_DIR . 'frontend/templates/booking-form.php';
        return ob_get_clean();
    }
}
