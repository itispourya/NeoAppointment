<?php
/**
 * Plugin Name: NeoAppointment
 * Plugin URI: https://neonotion.net
 * Description: A complete, modern 3D appointment booking system for WordPress
 * Version: 1.0.0
 * Author: NeoAppointment
 * by Pourya Omidian - NeoNotion - 2026
 * Author URI: https://neonotion.net
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit;
}

define('NEOAPPOINTMENT_VERSION', '1.0.0');
define('NEOAPPOINTMENT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('NEOAPPOINTMENT_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once NEOAPPOINTMENT_PLUGIN_DIR . 'includes/class-neoappointment-database.php';
require_once NEOAPPOINTMENT_PLUGIN_DIR . 'includes/class-neoappointment-admin.php';
require_once NEOAPPOINTMENT_PLUGIN_DIR . 'includes/class-neoappointment-frontend.php';
require_once NEOAPPOINTMENT_PLUGIN_DIR . 'includes/class-neoappointment-shortcode.php';

register_activation_hook(__FILE__, array('NeoAppointment_Database', 'install'));
register_deactivation_hook(__FILE__, array('NeoAppointment_Database', 'uninstall'));

function neoappointment_init() {
    new NeoAppointment_Admin();
    new NeoAppointment_Frontend();
    new NeoAppointment_Shortcode();
    neoappointment_check_default_colors();
}
add_action('plugins_loaded', 'neoappointment_init');

function neoappointment_check_default_colors() {
    global $wpdb;
    $table_settings = $wpdb->prefix . 'neoappointment_settings';
    
    $default_colors = array(
        'color_bg_primary' => '#0f0c29',
        'color_bg_secondary' => '#302b63',
        'color_bg_tertiary' => '#24243e',
        'color_text_primary' => '#00d2ff',
        'color_text_secondary' => '#3a7bd5',
        'color_btn_primary_1' => '#667eea',
        'color_btn_primary_2' => '#764ba2',
        'color_btn_secondary_1' => '#00d2ff',
        'color_btn_secondary_2' => '#3a7bd5',
        'color_success' => '#4caf50',
        'color_error' => '#f44336',
        'color_text' => '#ffffff',
        'color_input_bg' => 'rgba(255,255,255,0.1)',
        'color_select_bg' => 'rgba(255,255,255,0.1)'
    );
    
    foreach ($default_colors as $key => $value) {
        $exists = $wpdb->get_var($wpdb->prepare("SELECT setting_key FROM $table_settings WHERE setting_key = %s", $key));
        if (!$exists) {
            $wpdb->insert($table_settings, array(
                'setting_key' => $key,
                'setting_value' => $value
            ));
        }
    }
}
